/*
 * Class: CMSC203 
 * Instructor: Ahmed Tarek
 * Description: A program implemented with GUI that imitated a property management company
 * Due: 03/26/2024
 * Platform/compiler: eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ____Kebron Ghile______
*/
import java.util.ArrayList;

public class ManagementCompany {
	
	public static final int MAX_PROPERTY = 5;
	public static int MGMT_DEPTH =10;
	public static int MGMT_WIDTH =10;
	private String name; 
	private String taxID; 
	private double mgmFee;

	ArrayList<Property> properties = new ArrayList<Property>();
	
	
	
	
	public ManagementCompany() {
		this.name = "";
		this.taxID = "";
		this.mgmFee = 0;
		Plot pl =  new Plot(0,0,MGMT_WIDTH,MGMT_DEPTH);
		
		
	}
	//=================================================================================================//
	public ManagementCompany(String name, String taxID, double mgmFee) {
		this.name = name;
		this.taxID = taxID;
		this.mgmFee = mgmFee;
		Plot pl =  new Plot(0,0,MGMT_WIDTH,MGMT_DEPTH);
		
	}
	//=================================================================================================//
	public ManagementCompany(String name, String taxID, double mgmFee, int x, int y, int width, int depth) {
		this.name = name;
		this.taxID = taxID;
		this.mgmFee = mgmFee;
		Plot managmentPlot =  new Plot(x,y, width, depth);
		
	}
	//=================================================================================================//
	ManagementCompany(ManagementCompany otherCompany){
		
		new ManagementCompany(name, taxID,mgmFee);
		
		
	}
	//=================================================================================================//

	
	public int addProperty(String name, String city, double rent, String owner) {
		
		Property pr =new Property(name,city,rent,owner);	
		 int returnValue=0;
		 if (this.getProperties().size() == 5)
			 returnValue = -1;
		 else if (pr == null) 
			 returnValue = -2;
		 	 
		 else if (!(this.getPlot().encapsules(pr.getPlot()))) 
				returnValue = -3;
			
		 else if ((this.getPlot().overlaps(pr.getPlot()))) {
				returnValue = -4;
			}
		 for (int i= 0; i<properties.size() ; i++) {
			 if (pr.getPlot().overlaps(properties.get(i).getPlot())) {
				 returnValue = -4;
			 }
		 }
		 if (returnValue==0)
			 properties.add(pr);
			
		
   	
		return returnValue;
	}
	//=================================================================================================//

	public int  addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth) {
		Property pr = new Property(name,city,rent,owner,x,y,width,depth);
		Plot prPlot = new Plot (pr.getPlot());
		 int returnValue=0;
		 
		 if (this.getProperties().size() == 5)
			 returnValue = -1;
		 else if (pr == null) 
			 returnValue = -2;
		 
		 else if (!(this.getPlot().encapsules(prPlot))) 
				returnValue = -3;
			
		 else if (!(this.getPlot().overlaps(pr.getPlot()))) {
				returnValue = -4;
			}
		 for (int i= 0; i<properties.size() ; i++) {
			 if (pr.getPlot().overlaps(properties.get(i).getPlot())) {
				 returnValue = -4;
			 }
		 }
		 if (returnValue==0)
			 properties.add(pr);
		
		 
		 
		return returnValue;

	}

	//=================================================================================================//

     public int addProperty(Property property) {
    	 
    	 Property pr = new Property(property);
    	 int returnValue=0;
    	 
    	 if (this.getProperties().size() == 5)
			 returnValue = -1;
		 else if (pr == null) 
			 returnValue = -2;
		 	 
		 else if (!this.getPlot().encapsules(pr.getPlot())) 
			    returnValue = -3;

			
		 else if (!(this.getPlot().overlaps(pr.getPlot()))) {
				returnValue = -4;
			}
    	 for (int i= 0; i<properties.size() ; i++) {
			 if (pr.getPlot().overlaps(properties.get(i).getPlot())) {
				 returnValue = -4;
			 }
		 }
		 if (returnValue==0)
			 properties.add(pr);
    	 
    	
 	 
    	 return returnValue;
    	 
     }
	
   //=================================================================================================//

     public double getTotalFee() {
    	 double fee = (this.getMgmFeePer()/100) * this.getTotalRent() ;
    	 return fee;
     }
	//=================================================================================================//

	public Property getHighestRentPropperty() {
		Property highest= properties.getFirst();
		for(Property property : properties) {
			if( property != null)
				highest= property.getRentAmount() > highest.getRentAmount() ? property: highest;
		}
		
		return highest;
	}
	//=================================================================================================//
     public double getMgmFeePer() {
    	 return this.mgmFee;
     }
 	//=================================================================================================//
     public Plot getPlot() {
 		
 		 Plot pl = new Plot(0,0, MGMT_WIDTH, MGMT_DEPTH);
 		 return pl;
 		 
 		
 		
 	}
	
	//=================================================================================================//

	
	public ArrayList<Property> getProperties() {
		
		return this.properties;
		
	}
	//=================================================================================================//

	public int getPropertiesCount() {
		int PropertyCount= properties.size();
		
		return PropertyCount;
	}
	//=================================================================================================//
	public void removeLastProperty() {
		properties.removeLast();
	}
	
	//=================================================================================================//

	public boolean isPropertiesFull() {
		boolean isFull =false;
		
		if (properties.size() == MAX_PROPERTY) {
			isFull = true;
		}
		return isFull;
		
	}
	public String getName() {
		return this.name;
	}
	//=================================================================================================//

	public String getTaxId() { 
		return this.taxID;
	}

	//=================================================================================================//
	public double getTotalRent() {
		
		double totalRent =0;
		for(Property property : properties) {
			if( property != null)
			totalRent+= property.getRentAmount();	
		}
		return totalRent;
	}
	//=================================================================================================//
	public boolean isMangementFeeValid() {
		boolean valid =true;
		if(this.getMgmFeePer() < 0) {
			
		}
		return valid;
		
	}
	//=================================================================================================//
	
	public String toString() {
		String a= "List of the properties for " +  getName() +", taxID: " + getTaxId() + "\n";
		String hrLine = "______________________________________________________\n";
		String b= "";
		for(Property property : properties) {
				if(property!= null) {
					b+=property.toString() + "\n" ;	
				}	
		}
		String c= String.format("\n total management Fee: %.2f" , getTotalFee());
		return a+ hrLine + b + hrLine + c;
	}
	
	
	
	

}
