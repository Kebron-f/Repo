/*
 * Class: CMSC203 
 * Instructor: Ahmed Tarek
 * Description: A program implemented with GUI that imitated a property management company
 * Due: 03/26/2024
 * Platform/compiler: eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ____Kebron Ghile______
*/
public class Property {
	
	private String propertyName;
	private String city;
	private double rentAmount;
	private String owner;
	private int x ;
	private int y;
	private int width;
	private int depth;
	
	
	
	
	public Property() {
		
		this.x =0;
		this.y =0;
		this.width=1;
		this.depth =1;
		
	}
	
	public Property(String propertyName, String city, double rentAmount, String owner) {
		this.propertyName =propertyName;
		this.city = city;
		this.rentAmount = rentAmount;
		this.owner = owner;
		this.x =0;
		this.y =0;
		this.width=1;
		this.depth =1;
		
	}
	
	public Property(String propertyName, String city, double rentAmount, String owner, int x, int y, int width, int depth) {
		this.propertyName =propertyName;
		this.city = city;
		this.rentAmount = rentAmount;
		this.owner = owner;
		this.width= width;
		this.x= x;
		this.y=y;
		this.depth=depth;
		
	}
	public Property(Property otherProperty) {
		this.propertyName =otherProperty.getPropertyName();
		this.city = otherProperty.getCity();
		this.rentAmount = otherProperty.getRentAmount();
		this.owner = otherProperty.getOwner();
		this.width= otherProperty.getPlot().getWidth();
		this.x= otherProperty.getPlot().getX();
		this.y=otherProperty.getPlot().getY();
		this.depth=otherProperty.getPlot().getDepth();
	}
	
	public String getPropertyName() {
		return this.propertyName;
	}
	public String getCity() {
		return this.city;
	}
	public double getRentAmount() {
		return this.rentAmount;
	}
	public String getOwner() {
		return this.owner;
	}
	public Plot getPlot() {
		Plot pl = new Plot(x,y,width,depth);
		return pl;
	}
	
	
	public String toString() {
		return getPropertyName()+","  + getCity() +","  +  getOwner()+"," + String.format("%.1f", getRentAmount());
	}
	
	

}
