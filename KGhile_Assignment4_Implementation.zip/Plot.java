/*
 * Class: CMSC203 
 * Instructor: Ahmed Tarek
 * Description: A program implemented with GUI that imitated a property management company
 * Due: 03/26/2024
 * Platform/compiler: eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ____Kebron Ghile______
*/

public class Plot {
	
	private int x;
	private int y;
	private int width;
	private int depth;
	
	//constructor with default values
	public Plot() {
		this.width =1;
		this.depth = 1;
	}
	
	// constructor
	public Plot(int x , int y , int width ,int depth) {
		
		this.x = x;
		this.y= y;
		this.width= width;
		this.depth = depth;
		
	}
	public Plot(Plot otherplot) {
		
		this.x = otherplot.getX();
		this.y = otherplot.getY();
		this.width = otherplot.getWidth();
		this.depth = otherplot.getDepth();
		
		
	}
	//getter methods
	public  int getX() {
		return this.x;
			
	}
	public  int getY() {
		return this.y;
			
	}
	public  int getWidth() {
		return this.width;
			
	}
	public  int getDepth() {
		return this.depth;
			
	}
	//setter Methods
	
	public void setX(int x) {
		this.x =x;
	}
	public void sety(int y) {
		this.y =y;
	}
	public void setWidth(int width) {
		this.width =width;
	}
	public void setDepth(int depth) {
		this.depth =depth;
	}
	
	public  boolean overlaps(Plot p) {
		boolean overlap = true;
		
		int plx = this.getX();
		int ply = this.getY();
		int plW = this.getWidth();
		int plD = this.getDepth();
		
		int newPlx = p.getX();
		int newPly = p.getY();
		int newPlW= p.getWidth();
		int newPlD = p.getDepth();
		
		if ( (newPlx + newPlW) <= plx || newPlx >= (plx + plW) || newPly >= ply + plD || newPly + newPlD <= ply) {
			overlap = false;
		}
		return overlap;
	}
	
	public  boolean encapsules(Plot p) {
		boolean encapsule = true;
		
		int plx = this.getX();
		int ply = this.getY();
		int plW = this.getWidth();
		int plD = this.getDepth();
		
		int newPlx = p.getX();
		int newPly = p.getY();
		int newPlW= p.getWidth();
		int newPlD = p.getDepth();
		
		if ( (newPlx + newPlW) > (plx + plW) || newPlx < plx  || newPly< ply || newPly + newPlD > ply + plD) {
			encapsule = false;
		}
		
		return encapsule;
		}

	
	public String toString() {
		return getX() + "," + getY() + "," + getWidth() + "," + getDepth();
	}
	



	

}
