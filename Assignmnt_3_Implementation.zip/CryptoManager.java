/*
 * Class: CMSC203 
 * Instructor:
 * Description: (Give a brief description for each Class)
 * Due: MM/DD/YYYY
 * Platform/compiler:
 * I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: __________
*/
/**
 * @author Kebron Ghile
 * @version 2024.01
 */

public class CryptoManager {
	final static int STARTING_BOUND= 32;
	final static int ENDING_BOUND= 95;
	final static int RANGE = ENDING_BOUND-STARTING_BOUND +1;
	
	public static boolean isStringInBounds (String plainText) {
		boolean isValid = true;
		for(int i =0 ; i < plainText.length();i++ ) {
			
			if ((int) plainText.charAt(i) < 32 || (int) plainText.charAt(i) > 95  ){
				isValid = false;
				break;
			}
			
		}
		System.out.println(isValid);
		return isValid;
		
	}

	
	public static String caesarEncryption (String text, int key){
		
		String fullString = "";
		String upperText=text.toUpperCase();
		
		if (!isStringInBounds(text)) {
			fullString = "The selected string is not in bounds, Try again." ;
			return fullString;
		}
		
		for (int i = 0; i < text.length();i++) {
			
			int currentChar = (int)upperText.charAt(i);
			int encrypted = STARTING_BOUND+ (currentChar - STARTING_BOUND + key)% RANGE;
			char encryptedChar = (char) encrypted;
			fullString+= encryptedChar;
			
			
					
		}
		System.out.println("The given text :" + text);
		System.out.println("The Encrypted text :" + fullString);
		
		return fullString;
	}
public static String caesarDecryption(String encryptedText, int key){
		
		String fullString = "";
		encryptedText.toUpperCase();
		
		for (int i = 0; i < encryptedText.length();i++) 
		{
			int currentChar = (int)encryptedText.charAt(i);
			int decrypted = STARTING_BOUND + (currentChar - STARTING_BOUND - key + RANGE * RANGE) % RANGE;
			char decryptedChar = (char) decrypted;
			fullString+= decryptedChar;				
		}
		return fullString;
	}


public static String bellasoEncryption(String text, String key){
	
	String fullString = "";
	String adjustedKey="";
	String upperText =text.toUpperCase();
	key.toUpperCase();
	
	 // This for loop matches the length of key and plainText
	for ( int i = 0; i< text.length();i ++) {
		for(int j = 0 ;j<key.length(); j++) {
			while(adjustedKey.length() < text.length()) {
				adjustedKey+=key.charAt(j);
				break;
			}
		}	
	}
	
	
	for (int i = 0; i < text.length();i++) {
		
		int currentChar = (int)upperText.charAt(i);
		int currentKey = (int)adjustedKey.charAt(i);
		int encrypted = STARTING_BOUND+ (currentChar - STARTING_BOUND + currentKey)% RANGE;
		char encryptedChar = (char) encrypted;
		fullString+= encryptedChar;
		
		
	}
	System.out.println("The given text :" + text);
	System.out.println("The Encrypted text :" + fullString);
	
	return fullString;
	}

public static String bellasoDecryption(String encryptedText, String key){
	
	String fullString = "";
	String adjustedKey="";
	String upperText =encryptedText.toUpperCase();
	key.toUpperCase();
	
	for ( int i = 0; i< encryptedText.length();i ++) {
		for(int j = 0 ;j<key.length(); j++) {
			while(adjustedKey.length() < encryptedText.length()) {
				adjustedKey+=key.charAt(j);
				break;
			}
		}	
	}
	
	System.out.println("The given text :" + encryptedText);
	System.out.println("The Key text :" + adjustedKey);
	
	
	
	for (int i = 0; i < encryptedText.length();i++) {
		
		int currentChar = (int)upperText.charAt(i);
		int currentKey = (int)adjustedKey.charAt(i);
		int encrypted =   STARTING_BOUND + (currentChar - STARTING_BOUND - currentKey + RANGE * RANGE) % RANGE;
		char encryptedChar = (char) encrypted;
		fullString+= encryptedChar;
		
		
	}
	System.out.println("The Encrypted  text :" +encryptedText);
	System.out.println("The Decrypted text :" + fullString);
	
	return fullString;
	}
}
