import java.util.Scanner;
public class MovieDriver_Task1 {
	
	
		public static void main(String[] args) {
			Movie mov = new Movie();
			Scanner input = new Scanner(System.in);
			String answer = "";
			
			System.out.println("Enter the name of the movie?");
			String MovieName = input.nextLine();
			mov.setTitle(MovieName);
		
			System.out.println("Enter the rating of the movie?");
			String rating = input.nextLine();
			mov.setRating(rating);
		
			System.out.println("Enter the number of tickets sold?");
			int ticketsSold = input.nextInt();
			mov.setSoldTickets(ticketsSold);
		
			input.nextLine();
		
			System.out.println("Good Bye!");
			input.close();
}
		}
