import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTest {

	GradeBook g1 , g2;

	@BeforeEach
	void setUp() throws Exception {
		g1 = new GradeBook(3);
		g2 =new GradeBook(3);
		g1.addScore(50);
		g1.addScore(75);
		g2.addScore(100);
		g2.addScore(90);
		g2.addScore(80);
		
	}

	@AfterEach
	void tearDown() throws Exception {
		g1 = g2 = null;

	}
	
	@Test
	void testaddScore() {
		assertEquals("50.0,75.0,0.0" , g1.toString());
		assertTrue(g1.addScore(10));
		assertEquals(3,g2.getScoreSize());
		
	}
	@Test
	void testsum() {
		
		assertEquals(125,g1.sum());
		assertEquals(270,g2.sum());
	}
	
	@Test
	void testFinalScore() {
		
		assertEquals(125,g1.finalScore());
		assertEquals(190,g2.finalScore());
	}
	@Test
	void testMinimum() {
		
		assertEquals(50,g1.minimum());
		assertEquals(80,g2.minimum());
	}
		
	


	

}
