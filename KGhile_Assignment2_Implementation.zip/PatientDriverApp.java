/*
 * Class: CMSC203 
 * Instructor: Ahmed Tarek
 * Description: this program is designed to display patient information and procedures based on the arguments passed on to the constructor.
 * Due: 02/20/2024
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ____Kebron Ghile______
*/

import java.lang.*;
import  java.util.*;

public class PatientDriverApp {

	public static void main(String[] args) {
		final String programerName ="Kebron Ghile";
		final String dueDate = "02/20/2024";
		final String MCNumber = "M21165742";
		
		//N.B all arguments except charge should be enclosed by quotation
		Patient patient = new Patient("John","Mark","Doe", "111 E Franklin Ave" ,"Washington", "DC", "20444","Mark Stewer","2407434564");
		Procedure procedure1 = new Procedure("endarterectomy", "11/22/2019" , "Dr. Razi" , 15250.0);
		Procedure procedure2 = new Procedure("Debridement of wound", "11/22/2023" , "Dr. Stark" , 5500.43);
		Procedure procedure3 = new Procedure("Cataract surgery", "11/22/2021" , "Dr. Smith" , 1450.00);
		DisplayName(patient);
		DisplayProcedure(procedure1);
		DisplayProcedure(procedure2);
		DisplayProcedure(procedure3);
		DisplayTotal(procedure1,procedure2,procedure3);
		System.out.println("\nProgramer : " + programerName);
		System.out.println("MC# : " + MCNumber);
		System.out.println("Due Date : " + dueDate);
		
		System.exit(0);
		
		
		
	}
	
	public static void DisplayName(Patient procedure) {
		System.out.println(procedure.toString());
	}
	public static void DisplayProcedure(Procedure procedure) {
		System.out.println(procedure.toString());
	}
	
	public static void DisplayTotal(Procedure procedure1 ,Procedure procedure2 , Procedure procedure3) {
		double total = procedure1.getPrice() + procedure2.getPrice()+procedure3.getPrice() ;
		System.out.printf("\nCharge : $%.2f", total);
	}
	

}

class Patient //Patient class
{
	private String firstName;
	private String middleName;
	private String lastName;
	//Street Address, city, state, and ZIP code
	private String  streetAdress;
	private String city;
	private String state;
	private String zipCode;
	
	private String emergencyContactName;
	private String emergencyContactPhoneno;
	
	
	
	public Patient() {}
	
	public Patient(String first, String middle , String  last , String streetAdress , String city, String state, String zipCode, String emergencyContactName, String emergencyContactPhoneno ) {
		this.firstName = first;
		this.middleName = middle;
		this.lastName = last;
		this.streetAdress = streetAdress;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.emergencyContactName= emergencyContactName;
		this.emergencyContactPhoneno = emergencyContactPhoneno;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getStreetAdress() {
		return streetAdress;
	}
	public String getCity() {
		return city;
	}
	public String getState() {
		return state;
	}
	public String getZip() {
		return zipCode;
	}
	public String getEmergencyContactName() {
		return emergencyContactName;
	}
	public String getEmergencyContactPhoneno() {
		return emergencyContactPhoneno;
	}
	
	
	public void setFirstName(String FirstName) {
		this.firstName = FirstName;
	}
	public void setMiddleName( String MiddleName) {
		 this.middleName = MiddleName;
	}
	public void setLastName( String LastName) {
		this.lastName = LastName;
	}
	public void setStreetAdress(String StAdress) {
		this.streetAdress =  StAdress;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setZip(String zip) {
		this.zipCode = zip;
	}
	public void setEmergencyContactName(String emergencyName) {
		this.emergencyContactName = emergencyName;
	}
	public void setEmergencyContactPhoneno(String emergencyPhoneNo) {
		this.emergencyContactName = emergencyPhoneNo;
	}
	
	
	
	
	
	public String buildFullName(String first, String middle , String last) {
		String first1 = first.substring(0,1).toUpperCase() + first.substring(1);
		String middle1 = middle.substring(0,1).toUpperCase();
		String last1 = last.substring(0,1).toUpperCase() + last.substring(1);
		return  first1 + " " + middle1+ " " + last1;
	}
	
	public String buildFullAdress(String streetAdress, String city , String state , String zip) {
		String fullAdress = streetAdress + " " + city + " " + state + " " + zip ;
		return fullAdress;
	}
	public String buildContactInfo( String emergencyContactName , String ECPN) // ECPN = emergency contact Phone no
	{
		String emergencyContact = emergencyContactName + " " + ECPN.substring(0,3) + "-" + ECPN.substring(3,6) + "(" + ECPN.substring(6) + ")" ;
		return emergencyContact;
	}
	public String toString() {
		return "Patient Name: " + buildFullName(getFirstName(), getMiddleName(), getLastName()) + 
				"\nAdress: " + buildFullAdress(getStreetAdress(),getCity(),getState(),getZip()) +
				"\nEmergency Contact: " + buildContactInfo(getEmergencyContactName(),getEmergencyContactPhoneno());
	}
}

class Procedure{
	private String procedureName;
	private String procedureDate;
	private String practitioner;
	private double price; 
	
	public Procedure() {
			
	}
	public Procedure(String procedureName, String procedureDate, String practitioner , double price) {
		this.procedureName = procedureName;
		this.procedureDate = procedureDate;
		this.practitioner = practitioner;
		this.price = price;
		
	}
	
	public String getProcedureName() {
		return procedureName;
	}
	public String getProcedureDate() {
		return procedureDate;
	}
	public String getPractitioner() {
		return practitioner;
	}
	public double getPrice() {
		return price;
	}
	
	public void getProcedureName(String name) {
		this.procedureName = name;
	}
	public void getProcedureDate( String date) {
		this.procedureDate = date;
	}
	public void getPractitioner(String practitioner) {
		this.practitioner =practitioner;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String toString() {
		return "\n\tProcudure:" + getProcedureName() +
			   "\n\tDate: " + getProcedureDate() +
			   "\n\tPractitioner: " + getPractitioner()+
			   "\n\tprice:" + getPrice();
	}
	
}
